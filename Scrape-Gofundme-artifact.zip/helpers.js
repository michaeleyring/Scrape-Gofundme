const cheerio = require('cheerio');
const moment = require('moment');

function extractDonationsFromHTML (html) {
  const $ = cheerio.load(html); 
  const goaldetails = $('.goal');
  const fundraising = [];
  

  goaldetails.each(i,el) => {
    // Extract information from each row of the goal (should be one)
    let raised = $(el).find('strong').text().trim();
    let goal_amount = $(el).find('smaller').text().trim();
    //  let location = $(el).children('.views-field-name').text().trim();
    //    closing = moment(closing.slice(0, closing.indexOf('-') - 1), 'DD/MM/YYYY').toISOString();

    fundraising.push({raised, goal_amount});
  }); 
  
  return fundraising;
}

module.exports = {
  extractDonationsFromHTML
};